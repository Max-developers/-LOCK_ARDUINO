LiquidCrystal_I2C1602V1
=======================

## Does not work with Arduino 1.6.7, use this library instead https://github.com/openenergymonitor/LiquidCrystal_I2C

Arduino Library for HD44780 LCD with PCF8574 I2C controller

Based on DFRobot Library

http://www.dfrobot.com/wiki/index.php?title=I2C/TWI_LCD1602_Module_(SKU:_DFR0063)


